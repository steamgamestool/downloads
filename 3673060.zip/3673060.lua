-- 3673060's Lua and Manifest Created by Morrenus
-- How to Train Your Cock
-- Created: October 28, 2025 at 21:20:25 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3673060) -- How to Train Your Cock
-- MAIN APP DEPOTS
addappid(3673061, 1, "f1e81db7af0e94b79d5c102d03af8bbf130df1ec4da7894aaf4c5b9e9b75b930") -- Depot 3673061
setManifestid(3673061, "159948339915371392", 358761427)