-- 655770's Lua and Manifest Created by Morrenus
-- Crimson Gray
-- Created: October 02, 2025 at 02:08:03 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(655770) -- Crimson Gray
-- MAIN APP DEPOTS
addappid(655771, 1, "c0237f0e81e1f225f5c750a430ccc029bd52dcabbaf4976f56abf989a1b6198b") -- Crimson Gray Content
setManifestid(655771, "5066863131596394853", 409778997)