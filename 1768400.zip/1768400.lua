-- 1768400's Lua and Manifest Created by Morrenus
-- Archetype Arcadia
-- Created: October 02, 2025 at 23:26:00 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1768400) -- Archetype Arcadia
-- MAIN APP DEPOTS
addappid(1768401, 1, "c4938990abc28a97aceddba7a470c6e225ec0c87f58c5c435d84a1f2d268f25e") -- Depot 1768401
setManifestid(1768401, "1492432277725523795", 5089873532)