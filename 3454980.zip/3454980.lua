-- 3454980's Lua and Manifest Created by Morrenus
-- Mortal Kombat: Legacy Kollection
-- Created: October 30, 2025 at 10:30:24 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3454980) -- Mortal Kombat: Legacy Kollection
-- MAIN APP DEPOTS
addappid(3454981, 1, "a411f1c5ad0ff5f71b4e8aab564c7fd8fbd44ac3598a07480f2af377bcf65a9f") -- Depot 3454981
setManifestid(3454981, "6560034032350423247", 13390184276)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)