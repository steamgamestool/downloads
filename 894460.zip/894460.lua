-- 894460's Lua and Manifest Created by Morrenus
-- Crimson Gray: Dusk and Dawn
-- Created: October 01, 2025 at 19:09:27 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(894460) -- Crimson Gray: Dusk and Dawn
-- MAIN APP DEPOTS
addappid(894461, 1, "c6c9d093fa75e776e14fb47270445a5010b297be73d1414c9e448e3e8713ccc4") -- Crimson Gray: Dusk and Dawn Content
setManifestid(894461, "3767726896168860865", 390102942)