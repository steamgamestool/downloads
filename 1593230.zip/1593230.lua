-- 1593230's Lua and Manifest Created by Morrenus
-- Beneath
-- Created: October 28, 2025 at 09:31:09 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 1 (1 excluded)
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1593230) -- Beneath
-- MAIN APP DEPOTS
addappid(1593231, 1, "2905c8f1a5579ccc3d2502ca79a218c66afd497b3c23219ed643c55d3ddc0992") -- Depot 1593231
setManifestid(1593231, "5410292669382233055", 24412808290)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3907720) -- Beneath - The Golden Gun
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Beneath - Artbook (AppID: 4043680) - missing depot keys
-- addappid(4043680)