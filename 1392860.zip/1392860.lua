-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(1392860)
addappid(2088780)
addappid(2088783)
addappid(2088785)
addappid(2088786)
addappid(2088787)
addappid(2088788)
addappid(2170190)
addappid(1392863,0,"2a40e8e4f16a349cec1ad4cdd732e6a88afb1d0676c8de3061c87c7d815343d0")