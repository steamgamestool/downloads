-- 3410630's Lua and Manifest Created by Morrenus
-- Waning Flowers of a World Eternal - The Rainbow Appears After Flowering Rain
-- Created: October 02, 2025 at 12:07:09 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3410630) -- Waning Flowers of a World Eternal - The Rainbow Appears After Flowering Rain
-- MAIN APP DEPOTS
addappid(3410631, 1, "53981c14f20e803a4fa666700ab51a4b87f6fffa4773ef7e97d6721c61b17c0b") -- Depot 3410631
setManifestid(3410631, "6298280822272326669", 4214901997)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)