-- 1910090's Lua and Manifest Created by Morrenus
-- Towa and the Guardians of the Sacred Tree
-- Created: October 29, 2025 at 06:02:40 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(1910090) -- Towa and the Guardians of the Sacred Tree
-- MAIN APP DEPOTS
addappid(1910091, 1, "d8e9e0ca1f3a2acca398d8843b4b094078d30f9fa50e9d81f68d0e70c4509475") -- Depot 1910091
setManifestid(1910091, "3553553970514446528", 7090867203)
-- DLCS WITH DEDICATED DEPOTS
-- Towa and the Guardians of the Sacred Tree - Digital Artbook  Soundtrack (AppID: 3260020)
addappid(3260020)
addappid(3260020, 1, "bce2c8dec8e27769b1f0eeebcd1cbc7197428e62014dad5a3a68fc309330556a") -- Towa and the Guardians of the Sacred Tree - Digital Artbook  Soundtrack - Depot 3260020
setManifestid(3260020, "5381903434455449407", 122214858)
-- Towa and the Guardians of the Sacred Tree - Guardians Vestments (AppID: 3260030)
addappid(3260030)
addappid(3260030, 1, "fc672c58652e01e1c06f007954687bfb9a6220b7c2b030b02658229e755606e7") -- Towa and the Guardians of the Sacred Tree - Guardians Vestments - Depot 3260030
setManifestid(3260030, "5793858522405031322", 7744514)