-- 1598780's Lua and Manifest Created by Morrenus
-- Silly Polly Beast
-- Created: October 28, 2025 at 17:27:55 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1598780) -- Silly Polly Beast
-- MAIN APP DEPOTS
addappid(1598781, 1, "76b39dffdf80c1835c706057d496d22fdd5e7158980e1f8cbea6bcfb0cddd10f") -- Depot 1598781
setManifestid(1598781, "8448681582461157609", 4255270916)