-- 3113990's Lua and Manifest Created by Morrenus
-- Futamata Ren'ai: Two Times the Trouble
-- Created: October 02, 2025 at 10:07:18 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3113990) -- Futamata Ren'ai: Two Times the Trouble
-- MAIN APP DEPOTS
addappid(3113991, 1, "b641470769695b9a897f3f94e6e0a1d03405e31692a0b2d8840be47db021115b") -- Depot 3113991
setManifestid(3113991, "1184771978798102618", 1280131743)
addappid(3113992, 1, "94e2d569d6f1a79d2a465af3552dea127c08f94850dc6832d6bd528445d25c7d") -- Depot 3113992
setManifestid(3113992, "557519967790800414", 1278244465)
addappid(3113993, 1, "f108c69b750613efff832348553aad32f96d8ba7650c36e29be396464fa0dcb1") -- Depot 3113993
setManifestid(3113993, "9130442832046009806", 1280280538)